package com.zonesoft.person;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonApiApp {

	public static void main(String[] args) {
		SpringApplication.run(PersonApiApp.class, args);
	}

}
