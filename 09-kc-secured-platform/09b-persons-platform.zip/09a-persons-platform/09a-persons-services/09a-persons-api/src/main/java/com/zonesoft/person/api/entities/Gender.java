package com.zonesoft.person.api.entities;

public enum Gender {
	MALE,
	FEMALE
}
