import {configs as loggerConfigs} from './logger-config';
import getApiConfigs from './api-configs'; 

export default getApiConfigs;
export  {loggerConfigs};