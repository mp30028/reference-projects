import {levels} from 'loglevel';


//DEFAULT must always be present and set.
export const configs = {
	"DEFAULT": levels.DEBUG	
//	"Persons": levels.DEBUG,
//	"DropboxDemo": levels.SILENT,	
//	"BootstrapInlineTextEditDemo": levels.SILENT,
 
//	"Home": levels.SILENT,
//	
//	"Demo": levels.SILENT,
//	"MainApp": levels.SILENT,
//	
//	"Update": levels.SILENT,
//	"Fetch": levels.SILENT,	
//	"DataPutService": levels.SILENT,	
//
//	"Display": levels.SILENT,
//	"Generator": levels.SILENT,	
//	
//	
//	"Persons-EditablePerson": levels.DEBUG,
//	"Persons-EditableText": levels.DEBUG,
//	"Persons-SaveCancelButtons": levels.DEBUG,
//	"Persons-PersonsList": levels.DEBUG,
//	"PersonsMergeHandlers": levels.DEBUG,
//	"Persons-EditableDropdown": levels.DEBUG,
//	"Persons-OtherNames": levels.DEBUG,
//	"Persons-OtherNameItem": levels.DEBUG,
//	
//	"DataService": levels.SILENT,
//	"EventMessageHandler": levels.SILENT,
//	"DataMergeHandlers": levels.SILENT,
//	"EventService": levels.SILENT
}