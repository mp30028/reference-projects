import React, { useCallback, useEffect, useState } from 'react';
import getLogger from 'lib/logger';
import {Display, Generator} from 'ui/home/demo/sayings';

const Demo = () => {
	const MODULE = 'Demo'; 
	const LOGGER = getLogger(MODULE);
	const getSaying = useCallback(() => {return (new Generator()).getSaying},[]);
	const [currentSaying, setCurrentSaying] = useState(getSaying());
	
	const [isRegenerateAllTriggered, setIsRegenerateAllTriggered] = useState(false);
	
	LOGGER.debug({currentSaying},  {isRegenerateAllTriggered});
	
	useEffect(() => {
		if (isRegenerateAllTriggered){
			setCurrentSaying(getSaying());
			setIsRegenerateAllTriggered(false);
		}
	},[isRegenerateAllTriggered,getSaying])
			
	return (
		<>
			<span>
				<h2>From Demo ui component</h2>
				Adage   : {currentSaying.adage}<br/>
				Meaning : {currentSaying.meaning}
				
				<hr/>
				
				<Display label={'Child 1'} regenerateTriggered={isRegenerateAllTriggered} />
				
				<hr/>
				
				<Display label={'Child 2'} regenerateTriggered={isRegenerateAllTriggered} />
				
				<hr/>
				
				<input type='button' id='regenenerateAllButton' name= 'regenenerateAllButton' onClick={() => setIsRegenerateAllTriggered(true)} value='Regenerate All'/>
			</span>		
		</>	
	)
}

export default Demo;