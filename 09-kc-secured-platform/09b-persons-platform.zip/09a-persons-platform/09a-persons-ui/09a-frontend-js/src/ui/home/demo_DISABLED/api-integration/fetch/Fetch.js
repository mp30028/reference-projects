import React, {useState, useEffect, useRef}from 'react';
import DataService from 'lib/data-service';
import EventService, {EventMessageHandler} from 'lib/event-service';

const Fetch = () => {
	const API_URL = "https://localhost:7070/api/person";
	const EVENTS_URL = API_URL + "/events";
	const personsRef = useRef([]);
	const [data, setData] = useState(null);
	
	useEffect(()=>{
		const getData = () => personsRef.current;
		
		const setDataAndRef = (data) => {
			setData(data);
			personsRef.current = data;
		};
		
		
		const eventMessageHandler = new EventMessageHandler(getData, setDataAndRef);	
		(new DataService(API_URL)).fetchAll().then((data) => setData(data));
		(new EventService(EVENTS_URL)).listen(eventMessageHandler.messageHandler);		
	},[EVENTS_URL]);
	
	useEffect(() => {
		personsRef.current = data;
	},[data]);
	
	return (
		<span>
			<pre>
				{JSON.stringify(data,null,4)}
			</pre>
		</span>
	)
}

export default Fetch;
