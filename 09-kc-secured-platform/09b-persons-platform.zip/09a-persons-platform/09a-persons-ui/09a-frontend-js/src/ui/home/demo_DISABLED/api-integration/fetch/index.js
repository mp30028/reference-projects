import Fetch from './Fetch';

export default Fetch;