import React, {useState, useEffect, useMemo}from 'react';
import getLogger from 'lib/logger';
import DataService from 'lib/data-service';

const Update = () => {
	const MODULE = "Update";	
	const API_URL = "https://localhost:7070/api/person";			
	const [displayedValue, setDisplayedValue]= useState("");
	const [submitClicked, setSubmitClicked] = useState(false);
	const [submittedValue, setSubmittedValue] = useState(null);
	const LOGGER = useMemo(() => getLogger(MODULE),[MODULE]);

	useEffect(() => {		
		if (submitClicked){
			setSubmittedValue(displayedValue);
			setSubmitClicked(false);
		}
	},[submitClicked, displayedValue])
	
	useEffect(() => {
			LOGGER.debug("submittedValue", submittedValue);
			if (submittedValue){ 
				const submittedValueObj = JSON.parse(submittedValue);
				const dataService = new DataService(API_URL);
				dataService.update(submittedValueObj)
					.then((data) => {
						LOGGER.debug("data-returned", data);
						setDisplayedValue(JSON.stringify(data));
					});
				setSubmittedValue(null);
			}
	}, [submittedValue, LOGGER]);		

	const onChangeDisplayedValue = (event) => {
		const value = event.target.value;
		setDisplayedValue(value);
	}
	
	const onSubmitClick = () => {		
		setSubmitClicked(true);
	}
	
	return (
		<span>
			<textarea style={{height: 300 + 'px', width: 600 + 'px'}} value={displayedValue} onChange={onChangeDisplayedValue} />
				 
			<br/>
			
			<input type="submit" value="submit" onClick={onSubmitClick} />
		</span>
	)
}
export default Update;
