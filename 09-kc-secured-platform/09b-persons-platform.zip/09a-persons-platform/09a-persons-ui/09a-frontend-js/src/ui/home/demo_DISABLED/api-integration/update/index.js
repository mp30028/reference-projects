import Update from './Update';

export default Update;