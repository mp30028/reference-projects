import React, {useState, useEffect, useRef, useMemo} from 'react';
import getLogger from 'lib/logger';
import Form from 'react-bootstrap/Form';
import Stack from 'react-bootstrap/Stack';

const BootstrapInlineEditDemo = () => {
	const MODULE = "BootstrapInlineEditDemo";
	const LOGGER = getLogger(MODULE);
	const [testValue1, setTestValue1]=useState("One");
	const [testValue2, setTestValue2]=useState("Two");
	const [testValue3, setTestValue3]=useState("three");
	const [testValue4, setTestValue4]=useState("char-B");
	
	const saveChange = (id, changedItem) => {
		const MARKER = "[saveChange]";
		LOGGER.debug(MARKER, "triggered", {id}, {changedItem});
		switch(id){
			case "test-1":
				setTestValue1(changedItem);
				break;
			case "test-2":
				setTestValue2(changedItem);
				break;
			case "test-3":
				setTestValue3(changedItem);
				break;
			case "test-4":
				setTestValue4(changedItem);
				break;				
			default:
				LOGGER.warn(MARKER, "id not recognised",{id});
		}
	};

	const cancelChange = () => {
		const MARKER = "[cancelChange]";
		LOGGER.debug(MARKER, "triggered");
	};
	
	useEffect(()=>{
		const MARKER = "[testValues-Hook]";
		LOGGER.debug(MARKER, {testValue1}, {testValue2}, {testValue3});		
	},[LOGGER, testValue1, testValue2, testValue3])
	
	return (
		<>
			<Stack>
				<EditableText id="test-1" label="Test Value" value={testValue1} cancelHandler={cancelChange} saveHandler={saveChange} />
				<EditableText id="test-2" label="Test Value" value={testValue2}  cancelHandler={cancelChange} saveHandler={saveChange} />
				<EditableText id="test-3" label="Test Value" value={testValue3}  cancelHandler={cancelChange} saveHandler={saveChange} />
				<EditableDropdown 
					id="test-4" 
					label="Dropdown-Test" 
					value={testValue4}  
					cancelHandler={cancelChange} 
					saveHandler={saveChange}
					dropdownList={[
						{label: 'Alpha', value: 'char-A'},
      					{label: 'Bravo', value: 'char-B'},
      					{label: 'Charlie', value: 'char-C'}
      				]}
				/>
			</Stack>
		</>
	);
	
};

export default BootstrapInlineEditDemo;

/********************Component: EditableDropdown *********************************************************/
	const EditableDropdown = ({id, label, value, saveHandler, cancelHandler, dropdownList}) => {
		const MODULE = "EditableDropdown";
		const LOGGER = getLogger(MODULE);
		const isSaveNeeded = useRef(false);
		const currentValueBackup = useRef(null);
		const [currentValue, setCurrentValue]= useState(value);					
		
		const handlers = useMemo(() => {
			
			const save = () => {
				const MARKER = "[save]";
				LOGGER.debug(MARKER,"triggered");
				if (saveHandler){
					LOGGER.debug(MARKER,"saveHandler is set", {value}, {currentValue});
					saveHandler(id, currentValue);
				}else{
					LOGGER.debug(MARKER,"No saveHandler set", {value}, {currentValue});
				};
			};
		
			const cancel = () => {
				const MARKER = "[cancel]";
				LOGGER.debug(MARKER,"triggered");
				if (cancelHandler){
					LOGGER.debug(MARKER,"cancelHandler is set", {value}, {currentValue});
					cancelHandler();
				}else{
					LOGGER.debug(MARKER,"No cancelHandler set", {value}, {currentValue});
				}
			};			
			return new EditableComponentHandlers(isSaveNeeded, currentValueBackup, currentValue, setCurrentValue, cancel, save);
		},[LOGGER, currentValueBackup, currentValue, setCurrentValue, cancelHandler, saveHandler, id, value]);
				
		return(
			<>
				<Stack direction="horizontal" gap={1}>
					<span><Form.Label>{label}</Form.Label></span>
					<span>
					    <Form.Select 					    	
					    	value={currentValue}
							onFocus={handlers.handleOnFocus} 
							onChange={handlers.handleOnChange} 
							onKeyDown={handlers.handleOnKeyPress} 
							onBlur={handlers.handleOnBlur}							
					    >
					    	{dropdownList && 
					    		dropdownList.map((item) =>
									<option key={item.value} value={item.value}>{item.label}</option>
								)
							}							
						</Form.Select>
					</span>
				</Stack>		
			</>		
		);
	};


/********************Component: EditableText *********************************************************/
	const EditableText = ({id, label, value, saveHandler, cancelHandler}) => {
		const MODULE = "EditableText";
		const LOGGER = getLogger(MODULE);
		const isSaveNeeded = useRef(false);
		const currentValueBackup = useRef(null);
		const [currentValue, setCurrentValue]= useState(value);					
		
		const handlers = useMemo(() => {
			const save = () => {
				const MARKER = "[save]";
				LOGGER.debug(MARKER,"triggered");
				if (saveHandler){
					LOGGER.debug(MARKER,"saveHandler is set", {value}, {currentValue});
					saveHandler(id, currentValue);
				}else{
					LOGGER.debug(MARKER,"No saveHandler set", {value}, {currentValue});
				};
			};
		
			const cancel = () => {
				const MARKER = "[cancel]";
				LOGGER.debug(MARKER,"triggered");
				if (cancelHandler){
					LOGGER.debug(MARKER,"cancelHandler is set", {value}, {currentValue});
					cancelHandler();
				}else{
					LOGGER.debug(MARKER,"No cancelHandler set", {value}, {currentValue});
				}
			};			
			return new EditableComponentHandlers(isSaveNeeded, currentValueBackup, currentValue, setCurrentValue, cancel, save);
		},[LOGGER, currentValueBackup, currentValue, setCurrentValue, cancelHandler, saveHandler, id, value]);
				
		return (
			<>
				<Stack direction="horizontal" gap={3}>
					<span><Form.Label>{label}</Form.Label></span>
					<span>
						<Form.Control 
							type="text" 
							value={currentValue} 
							onFocus={handlers.handleOnFocus} 
							onChange={handlers.handleOnChange} 
							onKeyDown={handlers.handleOnKeyPress} 
							onBlur={handlers.handleOnBlur}/>
					</span>
				</Stack>		
			</>
		);
	};
	
/********************Class: EditableComponentHandlers *********************************************************/	
	class EditableComponentHandlers{
		MODULE = "EditableComponentHandlers";	
				
		constructor(isSaveNeeded, currentValueBackup, currentValue, setCurrentValue, cancel, save) {			
			this.LOGGER = getLogger(this.MODULE);
			this.currentValueBackup = currentValueBackup;
			this.currentValue = currentValue;
			this.setCurrentValue = setCurrentValue;
			this.cancel = cancel;
			this.save = save;
			this.isSaveNeeded = isSaveNeeded;
		};
			takeCurrentValueBackup = () =>{
				this.currentValueBackup.current = this.currentValue;
			};
			
			resetCurrentValueBackup = () =>{
				this.currentValueBackup.current = null;
			};
			
			getCurrentValueBackup = () => {
				return this.currentValueBackup.current;
			}
			
			setIsSaveNeeded = (b) => {
				this.isSaveNeeded.current = b;
			};
			
			getIsSaveNeeded = () => {
				return this.isSaveNeeded.current;
			}
	
			handleOnFocus = (event) => {
				const MARKER = "[handleOnFocus]";						
				this.LOGGER.debug(MARKER,{currentValue: this.currentValue});
				this.takeCurrentValueBackup();
				this.setIsSaveNeeded(true);
			};
			
			handleOnBlur = (event) => {
				const MARKER = "[handleOnBlur]";
				this.LOGGER.debug(MARKER,{currentValue: this.currentValue}, {isSaveNeeded: this.isSaveNeeded});
				if (!this.getIsSaveNeeded()){
					this.LOGGER.debug(MARKER, "Save NOT to be done so will discard any changes");
					this.setCurrentValue(this.getCurrentValueBackup());
					this.cancel();
				}else{
					this.LOGGER.debug(MARKER, "Save to be done");
					this.setIsSaveNeeded(false);
					this.save()
				}
				this.resetCurrentValueBackup();
			};
			
			handleOnKeyPress = (event) =>{
				const MARKER = "[handleOnKeyPress]";
				const keyPressed = event.keyCode;
				if(keyPressed === 13){
					this.LOGGER.debug(MARKER,"enter pressed.");
					this.setIsSaveNeeded(true);
					event.target.blur();
				}else if (keyPressed ===27){
					this.LOGGER.debug(MARKER,"escape pressed.");
					this.setIsSaveNeeded(false);
					event.target.blur();
				};
			}
			
			handleOnChange = (event) => {
				const MARKER = "[handleOnChange]";
				const inputValue = event.target.value;
				this.LOGGER.debug(MARKER,"triggered", {event});
				this.setCurrentValue(inputValue);
			}		
	}
