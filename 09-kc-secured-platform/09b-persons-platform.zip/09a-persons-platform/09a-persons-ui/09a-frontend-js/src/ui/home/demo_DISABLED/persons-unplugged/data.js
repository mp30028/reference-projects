export const personsData = [
{
  status: 0,
  data: {
    id: '67702181da3f24a1fcfb5a92',
    moniker: 'KamaKaxi',
    firstname: 'Carol',
    lastname: 'CAMERON',
    gender: 'FEMALE',
    otherNames: [
      {
        id: '677255fd5421916e9f56b994',
        value: 'Cam',
        nameType: 'ALIAS'
      },
      {
        id: '677255fd5421916e9f56b996',
        value: 'Anne',
        nameType: 'MIDDLE_NAME'
      }
    ]
  }
},
{
  status: 0,
  data: 
  {
    id: '67703a11da3f24a1fcfb5a98',
    moniker: 'Shrimp',
    firstname: 'Christopher',
    lastname: 'BROWN',
    gender: 'MALE',
    otherNames: [
      {
        id: '67703a11da3f24a1fcfb5a93',
        value: 'Blair',
        nameType: 'MIDDLE_NAME'
      }
    ]
  },
},
{
  status: 0,
  data:   
  {
    id: '67703a11da3f24a1fcfb5a99',
    moniker: 'Scary',
    firstname: 'Laura',
    lastname: 'STEWART',
    gender: 'FEMALE',
    otherNames: [
      {
        id: '67703a11da3f24a1fcfb5a94',
        value: 'Scaree',
        nameType: 'NICKNAME'
      },
      {
        id: '67703a11da3f24a1fcfb5a95',
        value: 'Strongo',
        nameType: 'MIDDLE_NAME'
      }
    ]
  },
},
{
  status: 0,
  data: 
  {
    id: '67703a11da3f24a1fcfb5a9a',
    moniker: 'Buzzard',
    firstname: 'Amanda',
    lastname: 'MURRAY',
    gender: 'FEMALE',
    otherNames: [
      {
        id: '67703a11da3f24a1fcfb5a96',
        value: 'Jane',
        nameType: 'MIDDLE_NAME'
      },
      {
        id: '67703a11da3f24a1fcfb5a97',
        value: 'Bozo',
        nameType: 'NICKNAME'
      }
    ]
  },
},
{
  status: 0,
  data: 
  {
    id: '6772ed4a818a2d445e458ee5',
    moniker: 'Mon-A',
    firstname: 'Fname-A',
    lastname: 'Lname-A',
    gender: 'MALE',
    otherNames: []
  }
} 
];