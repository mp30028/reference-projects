import PersonsUnplugged from "./PersonsUnplugged";

export default PersonsUnplugged;