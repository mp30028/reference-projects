import React, {useCallback, useEffect, useState} from 'react';
import getLogger from 'lib/logger';
import {Generator} from 'ui/home/demo/sayings';

const Display = ({label, regenerateTriggered}) => {
	const MODULE = 'Display'; 
	const LOGGER = getLogger(MODULE);
	const getSaying = useCallback(() => ((new Generator()).getSaying),[]);
	const [currentSaying, setCurrentSaying] = useState(getSaying());
	
	LOGGER.debug({label}, {currentSaying}, {regenerateTriggered});
	
	useEffect(()=>{
		setCurrentSaying(getSaying());
	},[regenerateTriggered, getSaying]);
	
	
	return (
		<>
			<span>
				<h4>From {label} of Demo ui component</h4>
				Adage   : {currentSaying.adage}<br/>
				Meaning : {currentSaying.meaning}<br/>
				<input type='button' id='regenenerateButton' name= 'regenenerateButton' onClick={() => setCurrentSaying(getSaying())} value={'Regenerate ' + label}/>
			</span>
		</>	
	)
}

export default Display;