import Display from './Display';

export default Display;