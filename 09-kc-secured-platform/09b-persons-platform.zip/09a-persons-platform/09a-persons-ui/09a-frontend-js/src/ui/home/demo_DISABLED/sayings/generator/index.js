import Generator from './Generator.class';

export default Generator;