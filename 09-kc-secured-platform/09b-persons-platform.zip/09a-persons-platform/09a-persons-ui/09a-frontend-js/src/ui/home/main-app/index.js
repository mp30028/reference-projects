import MainApp from "./MainApp";

export default MainApp;