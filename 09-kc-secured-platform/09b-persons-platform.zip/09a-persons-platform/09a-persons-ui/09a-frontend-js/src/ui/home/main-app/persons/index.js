import Persons from "./Persons";

export default Persons;